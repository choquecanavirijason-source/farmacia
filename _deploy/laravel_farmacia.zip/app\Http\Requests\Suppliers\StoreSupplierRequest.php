<?php

namespace App\Http\Requests\Suppliers;

use Illuminate\Foundation\Http\FormRequest;

class StoreSupplierRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return ['name' => 'required|string|max:255', 'nit' => 'nullable|string|max:255', 'phone' => 'nullable|string|max:255', 'address' => 'nullable|string|max:255', 'email' => 'nullable|email|max:255'];
    }
}
